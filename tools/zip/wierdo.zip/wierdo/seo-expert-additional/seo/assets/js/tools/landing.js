export function render(mount, ctx){
  mount.innerHTML = `
    <div class="tool-grid">
      <div class="card stack">
        <div class="label">Keyword / offer</div>
        <input id="lpKeyword" placeholder="contoh: live casino online" />
        <div class="label">USP / highlight</div>
        <input id="lpUSP" placeholder="contoh: deposit cepat, bonus harian, live 24 jam" />
        <div class="label">CTA</div>
        <input id="lpCTA" placeholder="contoh: daftar sekarang dan mulai main" />
        <button class="action-btn primary" id="lpGenerateBtn">Generate Landing Copy</button>
      </div>
      <div class="card">
        <h3>Output</h3>
        <p>Hasil berupa headline, subheadline, benefit, bullet point, dan CTA. Bukan builder HTML penuh, tapi cukup buat draft landing page cepat.</p>
      </div>
    </div>
    <div class="result-box"><pre id="lpResult">Draft landing akan muncul di sini.</pre></div>
  `;
  const result = mount.querySelector('#lpResult');
  mount.querySelector('#lpGenerateBtn').addEventListener('click', () => {
    const kw = mount.querySelector('#lpKeyword').value.trim();
    const usp = mount.querySelector('#lpUSP').value.trim();
    const cta = mount.querySelector('#lpCTA').value.trim() || 'Mulai sekarang';
    if(!kw){ ctx.toast('Keyword landing belum diisi.', 'error'); return; }
    result.textContent = `H1: ${kw} dengan Pengalaman yang Lebih Cepat dan Meyakinkan\n\nSubheadline: Temukan ${kw} dengan pendekatan yang lebih ringan, responsif, dan relevan untuk kebutuhan pengguna hari ini.\n\nBenefit:\n- Fokus pada kebutuhan user dan intent pencarian\n- Struktur copy lebih rapi dan enak dipindai\n- Cocok untuk hero section, benefit block, dan CTA area\n\nUSP: ${usp || 'Isi USP sesuai kebutuhan halaman'}\n\nCTA utama: ${cta}\nCTA pendukung: Cek detail, lihat penawaran, dan mulai dari halaman ini.`;
    ctx.toast('Draft landing page selesai.', 'success');
  });
}
