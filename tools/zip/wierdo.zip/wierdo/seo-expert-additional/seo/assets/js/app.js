const toolRegistry = {
  dashboard: { title: 'SEO Expert Dashboard', desc: 'Pusat kontrol SEO. Semua tool dipisah modular biar gak jadi gado-gado error.', module: './tools/dashboard.js', icon: '🧊', group: 'overview', groupLabel: 'Overview' },
  content: { title: 'Auto Content Generator', desc: 'Generate artikel SEO panjang, struktur heading, meta, CTA.', module: './tools/content.js', icon: '📝', group: 'content', groupLabel: 'Content Engine' },
  spinner: { title: 'Content Spinner', desc: 'Rewrite natural versi baru tanpa bikin kalimat jadi mabuk.', module: './tools/spinner.js', icon: '🔁', group: 'content', groupLabel: 'Content Engine' },
  landing: { title: 'Landing Page Generator', desc: 'Generate landing page copy siap edit dan publish.', module: './tools/landing.js', icon: '🧱', group: 'content', groupLabel: 'Content Engine' },
  assistant: { title: 'AI SEO Assistant', desc: 'Asisten SEO lokal untuk ide, CTA, outline, dan sudut konten.', module: './tools/assistant.js', icon: '🤖', group: 'content', groupLabel: 'Content Engine' },
  keyword: { title: 'Bulk Keyword Generator', desc: 'Generate keyword turunan tanpa batas artificial.', module: './tools/keyword.js', icon: '🔑', group: 'keyword', groupLabel: 'Keyword Tools' },
  density: { title: 'Keyword Density Advanced', desc: 'Analisa keyword 1-4 kata plus persen dan ranking.', module: './tools/density.js', icon: '📊', group: 'keyword', groupLabel: 'Keyword Tools' },
  cluster: { title: 'Keyword Clustering', desc: 'Kelompokkan keyword berdasarkan intent dan tema.', module: './tools/cluster.js', icon: '🧩', group: 'keyword', groupLabel: 'Keyword Tools' },
  serp: { title: 'SERP Snippet Preview', desc: 'Preview judul, URL, description dengan indikasi panjang.', module: './tools/serp.js', icon: '🔎', group: 'onpage', groupLabel: 'On Page SEO' },
  meta: { title: 'Meta Tag Generator', desc: 'Meta title, description, OG, dan Twitter card.', module: './tools/meta.js', icon: '🏷️', group: 'onpage', groupLabel: 'On Page SEO' },
  heading: { title: 'Heading Analyzer', desc: 'Cek H1-H4 dan struktur heading konten.', module: './tools/heading.js', icon: '🧱', group: 'onpage', groupLabel: 'On Page SEO' },
  score: { title: 'SEO Score Checker', desc: 'Skoring dasar konten berdasarkan panjang, heading, density, meta.', module: './tools/score.js', icon: '✅', group: 'onpage', groupLabel: 'On Page SEO' },
  link: { title: 'Internal Link Builder', desc: 'Variasi anchor dan internal link biar linking gak kering.', module: './tools/link.js', icon: '🔗', group: 'linking', groupLabel: 'Linking' },
  anchor: { title: 'Anchor Generator', desc: 'Generate anchor text exact, partial, branded, natural.', module: './tools/anchor.js', icon: '⚓', group: 'linking', groupLabel: 'Linking' },
  sitemap: { title: 'Sitemap Generator', desc: 'Generate sitemap.xml dari daftar URL.', module: './tools/sitemap.js', icon: '🗺️', group: 'technical', groupLabel: 'Technical SEO' },
  robots: { title: 'Robots.txt Generator', desc: 'Generate robots.txt bersih dan cepat.', module: './tools/robots.js', icon: '🤖', group: 'technical', groupLabel: 'Technical SEO' },
  indexer: { title: 'Indexing Helper', desc: 'Siapkan list submit URL dan payload ping helper.', module: './tools/indexer.js', icon: '📡', group: 'technical', groupLabel: 'Technical SEO' },
  image: { title: 'Image SEO Rename', desc: 'Slugify nama file, alt text, title, caption.', module: './tools/image.js', icon: '🖼️', group: 'media', groupLabel: 'Media SEO' },
};

const state = { activeTool: 'dashboard', loadedModules: new Map() };

const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];

function escapeHtml(str = '') {
  return str.replace(/[&<>"']/g, (m) => ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[m]));
}

function copyText(text, button) {
  navigator.clipboard.writeText(text).then(() => {
    if (button) {
      const old = button.textContent;
      button.textContent = 'Copied';
      button.classList.add('copied');
      setTimeout(() => { button.textContent = old; button.classList.remove('copied'); }, 1200);
    }
    toast('Berhasil dicopy. Ajaib, tombol kali ini benar-benar bekerja.', 'success');
  }).catch(() => toast('Gagal copy. Browser kadang memang suka cari perhatian.', 'error'));
}

function toast(message, type = 'success') {
  const stack = $('#toastStack');
  const el = document.createElement('div');
  el.className = `toast ${type}`;
  el.textContent = message;
  stack.appendChild(el);
  requestAnimationFrame(() => el.classList.add('show'));
  setTimeout(() => {
    el.classList.remove('show');
    setTimeout(() => el.remove(), 260);
  }, 2600);
}

function slugify(value = '') {
  return value
    .toLowerCase()
    .normalize('NFKD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9\s-]/g, ' ')
    .trim()
    .replace(/\s+/g, '-')
    .replace(/-+/g, '-');
}

function tokenize(text = '') {
  return text
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, ' ')
    .split(/\s+/)
    .filter(Boolean);
}

function buildNav(filter = '') {
  const q = filter.toLowerCase();
  const nav = $('#sidebarNav');
  const groups = {};
  for (const [id, tool] of Object.entries(toolRegistry)) {
    const hay = `${tool.title} ${tool.desc} ${tool.groupLabel}`.toLowerCase();
    if (q && !hay.includes(q)) continue;
    if (!groups[tool.group]) groups[tool.group] = { label: tool.groupLabel, items: [] };
    groups[tool.group].items.push({ id, ...tool });
  }
  nav.innerHTML = Object.values(groups).map(group => `
    <section class="nav-group">
      <div class="nav-title">${group.label}</div>
      ${group.items.map(tool => `
        <button class="nav-btn ${state.activeTool === tool.id ? 'active' : ''}" data-tool="${tool.id}">
          <span class="nav-icon">${tool.icon}</span>
          <span class="nav-copy">
            <strong>${tool.title}</strong>
            <small>${tool.desc}</small>
          </span>
        </button>
      `).join('')}
    </section>
  `).join('');

  $$('.nav-btn', nav).forEach(btn => btn.addEventListener('click', async () => {
    await loadTool(btn.dataset.tool);
    if (window.innerWidth <= 1080) $('.sidebar')?.classList.remove('open');
  }));
}

async function loadTool(id) {
  const config = toolRegistry[id];
  if (!config) return;
  state.activeTool = id;
  buildNav($('#toolSearch')?.value || '');
  $('#toolTitle').textContent = config.title;
  $('#toolDesc').textContent = config.desc;
  const mount = $('#workspaceMount');
  mount.innerHTML = '<div class="card"><h3>Loading...</h3><p>Tenang. Modul lagi dipanggil, bukan kabur.</p></div>';
  try {
    let mod = state.loadedModules.get(id);
    if (!mod) {
      mod = await import(config.module);
      state.loadedModules.set(id, mod);
    }
    mod.render(mount, { toast, copyText, escapeHtml, slugify, tokenize, toolRegistry, loadTool });
  } catch (err) {
    console.error(err);
    mount.innerHTML = `<div class="card"><h3>Tool error</h3><p>Modul <strong>${escapeHtml(id)}</strong> gagal dimuat. Detail: ${escapeHtml(String(err.message || err))}</p></div>`;
    toast('Ada modul yang ngambek. Cek console kalau mau tahu dosa detailnya.', 'error');
  }
}

$('#toolSearch').addEventListener('input', (e) => buildNav(e.target.value));
$('#toggleSidebarBtn').addEventListener('click', () => $('.sidebar')?.classList.toggle('open'));
$('#backDashboardBtn').addEventListener('click', () => loadTool('dashboard'));

window.SEOX = { toast, copyText, escapeHtml, slugify, tokenize, loadTool, toolRegistry };

buildNav();
loadTool('dashboard');
