
export function render(app){
  const cards = app.tools.filter(t => t.id !== 'dashboard').map(t => `
    <article class="tool-card">
      <div><div class="badge">${t.icon} ${t.title}</div><p>${t.desc}</p></div>
      <button class="btn primary" data-open="${t.id}">Buka Tool</button>
    </article>`).join('');
  return `
    <div class="card-grid">
      <section class="card two-col shrink">
        <div class="mini-card">
          <h3>Workspace compact & modular</h3>
          <p class="helper-text">Layout dipadatkan, mobile-friendly, focus mode, dan tool berat cuma load saat dipakai. Akhirnya fondasinya gak absurd lagi.</p>
        </div>
        <div class="stat-grid">
          <div class="stat-card"><span>Total Tools</span><strong>${app.tools.length}</strong></div>
          <div class="stat-card"><span>Theme</span><strong>${app.themes.length}</strong></div>
          <div class="stat-card"><span>User</span><strong>${app.getUser().username || 'Guest'}</strong></div>
          <div class="stat-card"><span>Mode</span><strong>Modular</strong></div>
        </div>
      </section>
      <section class="card">
        <div class="action-row" style="justify-content:space-between;align-items:center">
          <div><h3>Quick Launch</h3><div class="helper-text">Buka tool langsung dari dashboard.</div></div>
        </div>
        <div class="tool-grid single-mobile">${cards}</div>
      </section>
    </div>`;
}
export function init(app){
  document.querySelectorAll('[data-open]').forEach(btn => btn.addEventListener('click', ()=>{
    const target = document.querySelector(`.nav-btn[data-tool="${btn.dataset.open}"]`);
    if (target) target.click();
  }));
}
