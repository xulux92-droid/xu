import { $, $$, storage } from './core/utils.js';
import { groups, tools, toolMap } from './core/tool-config.js';
import { applyTheme, currentTheme, themes } from './core/theme.js';
import { loadTool } from './core/router.js';

const USERS = {
  owner: 'owner123',
  admin1: '123456',
  admin2: '123456',
};

const SESSION_IDLE_LIMIT = 30 * 60 * 1000;
const SESSION_MAX_LIMIT = 8 * 60 * 60 * 1000;

const app = {
  currentTool: storage.get('xu-last-tool', 'dashboard'),
  tools,
  groups,
  toolMap,
  getUser() {
    return storage.get('xu-user', { username: 'Guest', email: '' });
  },
  setUser(user) {
    storage.set('xu-user', user);
    updateUser();
  },
  setTheme: applyTheme,
  getTheme: currentTheme,
  themes,
  storage,
};

window.__XU_APP__ = app;

let workspaceStarted = false;
let sessionWatcher = null;

function showToast(message, type = 'error') {
  const stack = $('#toastStack');
  if (!stack) return;

  const el = document.createElement('div');
  el.className = `toast ${type}`;
  el.textContent = message;
  stack.appendChild(el);

  requestAnimationFrame(() => el.classList.add('show'));

  setTimeout(() => {
    el.classList.remove('show');
    setTimeout(() => el.remove(), 280);
  }, 2600);
}

function updateUser() {
  const user = app.getUser();
  const status = $('#userStatus');
  if (status) status.textContent = `User: ${user.username || 'Guest'}`;
}

function getSession() {
  try {
    return JSON.parse(localStorage.getItem('xu-auth') || 'null');
  } catch {
    return null;
  }
}

function setSession(username) {
  const now = Date.now();
  localStorage.setItem('xu-auth', JSON.stringify({
    username,
    loginAt: now,
    lastActive: now,
  }));
}

function touchSession() {
  const session = getSession();
  if (!session) return;
  session.lastActive = Date.now();
  localStorage.setItem('xu-auth', JSON.stringify(session));
}

function clearSession() {
  localStorage.removeItem('xu-auth');
  localStorage.removeItem('xu-user');
}

function isSessionValid(session) {
  if (!session || !session.username) return false;

  const now = Date.now();
  if ((now - session.lastActive) > SESSION_IDLE_LIMIT) return false;
  if ((now - session.loginAt) > SESSION_MAX_LIMIT) return false;

  return true;
}

function closeMobileSidebar() {
  $('#sidebar')?.classList.remove('open');
}

function lockApp() {
  workspaceStarted = false;
  document.body.classList.remove('auth-ready');
  document.body.classList.remove('focus-mode');
  document.body.classList.remove('sidebar-collapsed');
  document.body.classList.add('auth-locked');
  closeMobileSidebar();
}

function unlockApp(username) {
  storage.set('xu-user', { username, email: '' });

  document.body.classList.remove('auth-locked');
  document.body.classList.remove('focus-mode');
  document.body.classList.remove('sidebar-collapsed');
  document.body.classList.add('auth-ready');

  updateUser();
}

function logout(reason = '') {
  clearSession();
  lockApp();
  if (reason) showToast(reason, 'error');
}

function buildNav() {
  const q = ($('#navSearch')?.value || '').toLowerCase();
  const container = $('#navGroups');
  if (!container) return;

  container.innerHTML = groups.map(group => {
    const items = group.items
      .map(id => toolMap[id])
      .filter(Boolean)
      .filter(t => (`${t.title} ${t.desc}`).toLowerCase().includes(q));

    if (!items.length) return '';

    return `
      <section>
        <div class="group-title"><span>${group.label}</span></div>
        <div class="group-list">
          ${items.map(t => `
            <button class="nav-btn ${app.currentTool === t.id ? 'active' : ''}" data-tool="${t.id}">
              <span class="nav-icon">${t.icon}</span>
              <span class="nav-copy">
                <strong>${t.title}</strong>
                <small>${t.desc}</small>
              </span>
            </button>
          `).join('')}
        </div>
      </section>
    `;
  }).join('');

  $$('.nav-btn', container).forEach(btn => {
    btn.addEventListener('click', async () => {
      app.currentTool = btn.dataset.tool;
      storage.set('xu-last-tool', app.currentTool);
      buildNav();
      closeMobileSidebar();
      await loadTool(app.currentTool, app);
    });
  });
}

function bindShell() {
  $('#navSearch')?.addEventListener('input', buildNav);

  $('#sidebarToggle')?.addEventListener('click', () => {
    $('#sidebar')?.classList.toggle('open');
  });

  $('#collapseSidebarBtn')?.addEventListener('click', () => {
    document.body.classList.toggle('sidebar-collapsed');
  });

  $('#focusToggle')?.addEventListener('click', () => {
    document.body.classList.toggle('focus-mode');
  });

  $('#workspaceExpandBtn')?.addEventListener('click', () => {
    document.body.classList.toggle('focus-mode');
  });

  $('#themeQuickBtn')?.addEventListener('click', async () => {
    app.currentTool = 'settings';
    storage.set('xu-last-tool', app.currentTool);
    buildNav();
    await loadTool('settings', app);
  });

  $('#quickThemeBtn')?.addEventListener('click', async () => {
    app.currentTool = 'settings';
    storage.set('xu-last-tool', app.currentTool);
    buildNav();
    await loadTool('settings', app);
  });

  $('#logoutBtn')?.addEventListener('click', () => {
    logout('Logout berhasil.');
  });

  document.addEventListener('click', (e) => {
    if (
      window.innerWidth <= 920 &&
      !$('#sidebar')?.contains(e.target) &&
      e.target.id !== 'sidebarToggle'
    ) {
      closeMobileSidebar();
    }
  });
}

function bindLogin() {
  const form = $('#loginForm');
  const usernameEl = $('#username');
  const passwordEl = $('#password');

  if (!form || !usernameEl || !passwordEl) return;

  form.addEventListener('submit', async (e) => {
    e.preventDefault();

    const username = usernameEl.value.trim();
    const password = passwordEl.value.trim();

    if (!username || !password) {
      showToast('Isi username dan password dulu.', 'error');
      return;
    }

    if (!USERS[username] || USERS[username] !== password) {
      showToast('Login gagal. Cek lagi ID atau password-nya.', 'error');
      return;
    }

    setSession(username);
    unlockApp(username);
    showToast('Login berhasil. Dashboard dibuka.', 'success');
    await startWorkspace(true);
  });
}

async function startWorkspace(force = false) {
  if (workspaceStarted && !force) return;
  workspaceStarted = true;

  applyTheme(currentTheme());
  updateUser();
  buildNav();
  await loadTool(app.currentTool || 'dashboard', app);

  requestAnimationFrame(() => {
    window.dispatchEvent(new Event('resize'));
  });
}

function bindSessionActivity() {
  const events = ['click', 'keydown', 'mousemove', 'scroll', 'touchstart'];
  events.forEach(evt => {
    document.addEventListener(evt, () => {
      if (document.body.classList.contains('auth-ready')) {
        touchSession();
      }
    }, { passive: true });
  });
}

function watchSession() {
  if (sessionWatcher) clearInterval(sessionWatcher);

  sessionWatcher = setInterval(() => {
    if (!document.body.classList.contains('auth-ready')) return;

    const session = getSession();
    if (!isSessionValid(session)) {
      logout('Sesi habis. Login lagi ya.');
    }
  }, 15000);
}

async function initAuth() {
  const session = getSession();

  if (isSessionValid(session)) {
    unlockApp(session.username);
    touchSession();
    await startWorkspace(true);
  } else {
    clearSession();
    lockApp();
  }

  bindSessionActivity();
  watchSession();
}

bindShell();
bindLogin();
initAuth();