export const groups = [
  { key:'core', label:'Core', items:['dashboard','auth','settings'] },
  { key:'text', label:'Text & SEO', items:['notepad','wordcounter','wordtohtml','htmlcleaner','keyworddensity','aitools','seoxu','domainchecker'] },
  { key:'dev', label:'Dev', items:['terminal','phpobfuscator','base64','codeeditor','scanner'] },
  { key:'media', label:'Media & Files', items:['uploader','filemanager','mediaplayer','calculator'] },
  { key:'comms', label:'Communication', items:['minidiscord'] },
  { key:'seo', label:'SEO Expert', items:['seo-expert'] }
];

export const tools = [
  { id:'dashboard', title:'Dashboard', desc:'Ringkasan workspace dan quick launch.', icon:'🏠' },
  { id:'auth', title:'Auth', desc:'Status user dan manajemen pengguna owner-only.', icon:'🔐' },
  { id:'notepad', title:'Notepad', desc:'Catatan kerja cepat.', icon:'📒' },
  { id:'wordcounter', title:'Word Counter', desc:'Hitung kata, karakter, paragraf.', icon:'📝' },
  { id:'filemanager', title:'File Manager', desc:'Daftar file dan folder lokal.', icon:'📁' },
  { id:'uploader', title:'Uploader', desc:'Upload file publik + wget/curl.', icon:'🚀' },
  { id:'calculator', title:'Calculator', desc:'Kalkulator cepat dan keyboard-ready.', icon:'🧮' },
  { id:'wordtohtml', title:'Word to HTML', desc:'Editor visual ke HTML bersih.', icon:'🔤' },
  { id:'scanner', title:'Scanner', desc:'Deteksi pattern mencurigakan.', icon:'🛡️' },
  { id:'domainchecker', title:'Domain Checker', desc:'DNS, helper, dan audit dasar.', icon:'🌐' },
  { id:'mediaplayer', title:'Media Player', desc:'Audio, video, gambar, suara.', icon:'🎬' },
  { id:'terminal', title:'Terminal', desc:'Console demo dengan command helper.', icon:'⌨️' },
  { id:'settings', title:'Settings', desc:'Theme, mobile, focus mode.', icon:'⚙️' },
  { id:'phpobfuscator', title:'PHP Obfuscator', desc:'Obfuscator tanpa limit input.', icon:'🧬' },
  { id:'base64', title:'Base64', desc:'Encode/decode tanpa limit input.', icon:'🔐' },
  { id:'aitools', title:'AI Tools', desc:'Generator pintar tanpa API.', icon:'🤖' },
  { id:'seoxu', title:'SEO-XU', desc:'Audit cepat dan helper SEO.', icon:'🚦' },
  { id:'htmlcleaner', title:'HTML Cleaner', desc:'Bersihkan HTML kotor.', icon:'🧼' },
  { id:'keyworddensity', title:'Keyword Density', desc:'Top keyword dan persen.', icon:'📊' },
  { id:'codeeditor', title:'Code Editor', desc:'VS mode dengan Monaco on demand.', icon:'💻' },
  { id:'minidiscord', title:'Mini Discord', desc:'DM pribadi, voice call, video call, group call.', icon:'💬' },
  { id:'seo-expert', title:'SEO Expert', desc:'Full SEO workspace: content, keyword, optimization.', icon:'🚀' }
];

export const toolMap = Object.fromEntries(tools.map(t => [t.id, t]));