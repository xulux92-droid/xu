export function render() {
  return `
    <section class="card">
      <div class="action-row" style="justify-content:space-between;align-items:flex-start;gap:14px;flex-wrap:wrap">
        <div>
          <h3 style="margin:0 0 6px">🚀 SEO Expert</h3>
          <div class="helper-text">
            Workspace SEO dipisah dari tools utama biar performa tetap ringan dan script tidak saling tabrak.
          </div>
        </div>
      </div>

      <div class="tool-grid single-mobile" style="margin-top:14px">
        <article class="tool-card">
          <div>
            <div class="badge">🧠 SEO Workspace</div>
            <p style="margin-top:10px">
              Buka halaman SEO Expert terpisah yang berisi content generator, keyword tools, density, SERP, link builder, dan tools SEO lainnya.
            </p>
          </div>
          <div class="action-row" style="margin-top:12px">
            <button class="btn primary" id="seoExpertOpenSameTab">Buka SEO Expert</button>
            <button class="btn ghost" id="seoExpertOpenNewTab">Tab Baru</button>
          </div>
        </article>

        <article class="tool-card">
          <div>
            <div class="badge">📍 Path</div>
            <p style="margin-top:10px">
              Target URL:
            </p>
            <div class="output-box" style="margin-top:8px">/lampha/workspace/seo/</div>
          </div>
          <div class="helper-text" style="margin-top:12px">
            Kalau halaman SEO sudah terpasang benar, tombol di kiri akan langsung membuka tool SEO Expert.
          </div>
        </article>
      </div>
    </section>
  `;
}

export function init() {
  const targetUrl = '/lampha/workspace/seo/';

  document.getElementById('seoExpertOpenSameTab')?.addEventListener('click', () => {
    window.location.href = targetUrl;
  });

  document.getElementById('seoExpertOpenNewTab')?.addEventListener('click', () => {
    window.open(targetUrl, '_blank');
  });
}