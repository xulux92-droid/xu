import { $, escapeHtml, formatBytes, copyText, notify } from '../core/utils.js';

let currentResponse = null;

function buildOutputRows(data){
  const rows = [
    { label:'Public URL', value:data.url, note:'Link publik file hasil upload.' },
    { label:'wget Linux', value:`wget "${data.url}"`, note:'Perintah wget untuk Linux / Termux.' },
    { label:'curl Linux', value:`curl -L -o "${data.filename}" "${data.url}"`, note:'Ambil file lewat curl.' },
    { label:'PowerShell', value:`Invoke-WebRequest -Uri "${data.url}" -OutFile "${data.filename}"`, note:'Unduh file via PowerShell Windows.' },
    { label:'Windows CMD', value:`curl -L -o "${data.filename}" "${data.url}"`, note:'CMD modern yang sudah ada curl.' },
    { label:'HTML', value:`<a href="${data.url}">${data.filename}</a>`, note:'Snippet HTML siap tempel.' },
    { label:'Markdown', value:`[${data.filename}](${data.url})`, note:'Format Markdown buat catatan / repo.' },
  ];

  return rows.map((row, idx) => `
    <article class="result-box">
      <div class="result-box-head">
        <div>
          <strong>${row.label}</strong>
          <small>${row.note}</small>
        </div>
        <button class="btn ghost copy-btn" data-copy="${escapeHtml(row.value)}">Copy</button>
      </div>
      <div class="code-box result-code">${escapeHtml(row.value)}</div>
    </article>
  `).join('');
}

function renderMeta(file){
  const ext = (file.name.split('.').pop() || '').toLowerCase();
  $('#uploadMeta').innerHTML = `
    <div class="upload-meta-grid">
      <div class="meta-pill"><span>File</span><strong>${escapeHtml(file.name)}</strong></div>
      <div class="meta-pill"><span>Ukuran</span><strong>${formatBytes(file.size)}</strong></div>
      <div class="meta-pill"><span>Tipe</span><strong>${escapeHtml(file.type || 'unknown')}</strong></div>
      <div class="meta-pill"><span>Ext</span><strong>${escapeHtml(ext || '-')}</strong></div>
    </div>
  `;
}

function bindCopies(){
  document.querySelectorAll('.copy-btn').forEach(btn => {
    btn.onclick = async () => {
      const text = (btn.dataset.copy || '').replace(/&quot;/g,'"').replace(/&#39;/g,"'");
      await copyText(text);
      notify('Berhasil dicopy.');
    };
  });
}

export function render(){
  return `
    <div class="card-grid">
      <section class="card">
        <div class="section-head">
          <div>
            <h3>Upload file publik</h3>
            <p class="helper-text">Fungsi upload sudah aman. Sekarang tampilannya gue rapihin biar gak kayak hasil lempar dari truk berjalan.</p>
          </div>
        </div>

        <div class="upload-shell">
          <div class="mini-card upload-pane">
            <h4>Pilih file</h4>
            <div id="uploadDrop" class="dropzone tall-dropzone">
              <strong>Drop file di sini</strong>
              <span>atau klik tombol pilih file manual</span>
            </div>
            <input id="uploadFile" type="file" hidden />
            <div class="action-row">
              <button class="btn primary" id="pickUploadBtn">Pilih File</button>
              <button class="btn ghost" id="sendUploadBtn">Upload</button>
              <button class="btn ghost" id="resetUploadBtn">Reset</button>
            </div>
            <div id="uploadMeta" class="info-box compact-info">
              Tool ini pakai <code>api/upload.php</code>. File berbahaya tetap disimpan aman dalam mode non-executable.
            </div>
            <div class="progress large-progress"><span id="uploadBar"></span></div>
          </div>

          <div class="mini-card upload-pane">
            <h4>Hasil gfupload style</h4>
            <div id="uploadResult" class="result-stack">
              <div class="info-box">Belum ada hasil upload.</div>
            </div>
          </div>
        </div>
      </section>
    </div>
  `;
}

export function init(){
  const input = $('#uploadFile');
  const drop = $('#uploadDrop');
  let file = null;

  $('#pickUploadBtn').onclick = () => input.click();

  input.onchange = e => {
    file = e.target.files?.[0] || null;
    if(file) renderMeta(file);
  };

  ['dragenter','dragover'].forEach(evt =>
    drop.addEventListener(evt, e => {
      e.preventDefault();
      drop.classList.add('dragover');
    })
  );

  ['dragleave','drop'].forEach(evt =>
    drop.addEventListener(evt, e => {
      e.preventDefault();
      drop.classList.remove('dragover');
    })
  );

  drop.addEventListener('drop', e => {
    file = e.dataTransfer.files?.[0] || null;
    if(file){
      input.files = e.dataTransfer.files;
      renderMeta(file);
    }
  });

  $('#sendUploadBtn').onclick = async () => {
    if(!file) return notify('Pilih file dulu.');
    $('#uploadBar').style.width = '18%';

    const fd = new FormData();
    fd.append('file', file);

    try{
      const res = await fetch('api/upload.php', { method:'POST', body:fd });
      const raw = await res.text();
      let data;

      try{
        data = JSON.parse(raw);
      }catch{
        throw new Error('Server tidak mengembalikan JSON valid. Biasanya hosting lo nyelipin halaman error atau ModSecurity.');
      }

      if(!res.ok || !data.ok) throw new Error(data.error || 'Upload gagal');

      currentResponse = data;
      $('#uploadBar').style.width = '100%';

      const safeNote = data.safe_renamed ? `
        <div class="result-alert">
          <strong>Safe mode aktif</strong>
          <span>${escapeHtml(data.note || 'File disimpan non-executable agar aman.')}</span>
        </div>` : '';

      $('#uploadResult').innerHTML = `
        ${safeNote}
        <div class="upload-summary">
          <div class="file-row">
            <div>
              <strong>${escapeHtml(data.filename)}</strong>
              <div class="muted">${formatBytes(data.size)} · <a href="${data.url}" target="_blank" rel="noopener">Open</a></div>
            </div>
          </div>
        </div>
        ${buildOutputRows(data)}
      `;
      bindCopies();
      notify('Upload selesai.');
    }catch(err){
      $('#uploadBar').style.width = '0%';
      $('#uploadResult').innerHTML = `
        <div class="info-box">
          Upload gagal.<br><br>${escapeHtml(err.message)}<br><br>
          <strong>Checklist cepat:</strong><br>
          1. Folder <code>uploads/</code> writable<br>
          2. PHP aktif<br>
          3. Hosting tidak memblok upload file ini<br>
          4. Path project tetap di <code>/lampha/workspace/</code> atau setara
        </div>
      `;
    }
  };

  $('#resetUploadBtn').onclick = () => {
    file = null;
    currentResponse = null;
    input.value = '';
    $('#uploadBar').style.width = '0%';
    $('#uploadResult').innerHTML = '<div class="info-box">Belum ada hasil upload.</div>';
    $('#uploadMeta').innerHTML = 'Tool ini pakai <code>api/upload.php</code>. File berbahaya tetap disimpan aman dalam mode non-executable.';
  };
}
