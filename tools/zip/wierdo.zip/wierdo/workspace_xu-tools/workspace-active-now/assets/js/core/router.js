
import { $, notify } from './utils.js';
import { toolMap } from './tool-config.js';
const moduleCache = new Map();
export async function loadTool(id, app){
  const mount = $('#viewMount');
  if(!mount) return;
  const meta = toolMap[id] || toolMap.dashboard;
  $('#viewTitle').textContent = meta.title;
  $('#viewDescription').textContent = meta.desc;
  mount.innerHTML = `<div class="card"><div class="loader">Memuat ${meta.title}...</div></div>`;
  let mod = moduleCache.get(id);
  if(!mod){
    try{ mod = await import(`../tools/${id}.js`); moduleCache.set(id, mod); }
    catch(err){
      mount.innerHTML = `<div class="card"><h3>Gagal memuat tool</h3><div class="output-box">${err.message}</div></div>`;
      console.error(err); return;
    }
  }
  mount.innerHTML = mod.render(app);
  try{ mod.init?.(app); }
  catch(err){ console.error(err); notify(`Ada error saat init ${meta.title}`); }
}
