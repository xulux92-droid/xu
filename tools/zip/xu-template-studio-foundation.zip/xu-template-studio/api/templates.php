<?php
header('Content-Type: application/json; charset=utf-8');
$file = __DIR__ . '/../storage/templates-manifest.json';
if (!file_exists($file)) { echo json_encode(['templates'=>[]]); exit; }
readfile($file);
