<?php
header('Content-Type: application/json; charset=utf-8');
$raw = file_get_contents('php://input');
$data = json_decode($raw, true);
if (!$data || empty($data['html']) || empty($data['filename'])) {
  http_response_code(400); echo json_encode(['ok'=>false,'error'=>'Invalid export payload']); exit;
}
$name = preg_replace('/[^a-zA-Z0-9._-]/', '-', $data['filename']);
$path = __DIR__ . '/../storage/exports/' . $name;
file_put_contents($path, $data['html']);
echo json_encode(['ok'=>true,'file'=>'storage/exports/'.$name]);
