<?php
return [
  'app_name' => 'Xu Template Studio',
  'version' => '1.0-foundation',
  'brands' => ['indojawa88', 'wahanabet'],
  'types' => ['amp', 'konten'],
  'theme' => 'obsidian-red'
];
