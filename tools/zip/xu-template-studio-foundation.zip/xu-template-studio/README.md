# Xu Template Studio v1.0 Foundation

Fokus project: Template Editor untuk brand INDOJAWA88 dan WAHANABET.

## Cara pakai

1. Upload folder ini ke hosting lokal/cPanel yang support PHP.
2. Buka `index.php`.
3. Masuk ke Template Library.
4. Pilih template.
5. Edit placeholder + HTML.
6. Preview live.
7. Export HTML.

## Struktur penting

```txt
templates/{brand}/{amp|konten}/{family}/{template-id}/template.html
storage/templates-manifest.json
storage/exports/
```

## Catatan

Ini masih Sprint 1 Foundation. Monaco Editor, auth, version history, dan UI final akan masuk sprint berikutnya.
