<?php
session_start();
define('XTS_ROOT', __DIR__);
define('XTS_VERSION', '1.0-foundation');
require_once __DIR__ . '/app/config.php';
?>
<!doctype html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Xu Template Studio</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="assets/css/app.css">
</head>
<body>
  <div class="xts-bg"><span></span><span></span><span></span></div>
  <div id="app" class="xts-shell">
    <aside class="sidebar">
      <div class="brandmark"><div class="logo">XTS</div><div><b>Xu Template</b><small>Studio</small></div></div>
      <nav class="nav">
        <button class="nav-item active" data-page="dashboard">⌂ <span>Dashboard</span></button>
        <button class="nav-item" data-page="projects">▣ <span>Projects</span></button>
        <button class="nav-item" data-page="library">◈ <span>Template Library</span></button>
        <button class="nav-item" data-page="editor">✎ <span>Editor</span></button>
        <button class="nav-item" data-page="export">⇩ <span>Export</span></button>
        <button class="nav-item" data-page="settings">⚙ <span>Settings</span></button>
      </nav>
      <div class="sidebar-foot"><small>Obsidian Red</small><b>v1.0 Foundation</b></div>
    </aside>

    <main class="workspace">
      <header class="topbar">
        <div><h1 id="pageTitle">Dashboard</h1><p id="pageSub">Fondasi baru, rapi, dan gak kayak folder hasil panik.</p></div>
        <div class="top-actions"><input id="globalSearch" placeholder="Search template..."/><button id="themeBtn">Theme</button></div>
      </header>
      <section id="view" class="view"></section>
      <footer class="statusbar"><span id="statusText">Ready</span><span>Xu-SEO Template Engine</span></footer>
    </main>
  </div>
  <script type="module" src="assets/js/app.js"></script>
</body>
</html>
